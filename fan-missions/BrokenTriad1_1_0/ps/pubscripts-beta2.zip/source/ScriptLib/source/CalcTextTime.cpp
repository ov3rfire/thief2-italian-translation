/******************************************************************************
 *    CalcTextTime.cpp
 *
 *    This file is part of Object Script Library
 *    Copyright (C) 2005-2007 Tom N Harris <telliamed@whoopdedo.org>
 *
 *    Permission is hereby granted, free of charge, to any person obtaining
 *    a copy of this software and associated documentation files (the 
 *    "Software"), to deal in the Software without restriction, including 
 *    without limitation the rights to use, copy, modify, merge, publish, 
 *    distribute, sublicense, and/or sell copies of the Software, and to 
 *    permit persons to whom the Software is furnished to do so.
 *    
 *    THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, 
 *    EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES 
 *    OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NON-
 *    INFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS 
 *    BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN 
 *    AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR 
 *    IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN 
 *    THE SOFTWARE.
 *
 *****************************************************************************/

#include <ctype.h>

int CalcTextTime(const char* pszText, int iWordTime)
{
	register const char *p = pszText;
	register const char *q = p;
	register int c = 0, e = 0;
	while (*p)
	{
		if (isspace(*p))
		{
			if ((p - q) + e > 3)
			{
				++c;
				e = 0;
			}
			else
				++e;
			while (isspace(*++p)) ;
			q = p;
			continue;
		}
		++p;
	}
	if ((p - q) + e > 3)
		++c;
	//if (c < ((p-pszText)/8))
	//	c = (p-pszText)/8;
	return iWordTime * ((c < 10) ? 10 : c);
}
