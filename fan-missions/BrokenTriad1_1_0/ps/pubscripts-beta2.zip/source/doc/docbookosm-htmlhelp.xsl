<xsl:stylesheet
  xmlns:xsl="http://www.w3.org/1999/XSL/Transform"
  version='1.0'>
  <xsl:import href="http://docbook.sourceforge.net/release/xsl/current/htmlhelp/htmlhelp.xsl"/>
  <xsl:output method="html" encoding="ISO-8859-1" indent="no"/>
  <xsl:param name="html.stylesheet" select="'style.css'"></xsl:param>
  <xsl:param name="chunker.output.encoding" select="'ISO-8859-1'"></xsl:param>
  <xsl:param name="chunk.first.sections" select="1"></xsl:param>
  <xsl:param name="label.from.part" select="1"></xsl:param>
  <xsl:param name="part.autolabel" select="0"></xsl:param>
  <xsl:param name="chapter.autolabel" select="1"></xsl:param>
  <xsl:param name="section.autolabel" select="0"></xsl:param>
  <xsl:param name="preface.autolabel" select="0"></xsl:param>
  <xsl:param name="appendix.autolabel" select="0"></xsl:param>

  <xsl:param name="variablelist.as.table" select="1"></xsl:param>
  <xsl:param name="segmentedlist.as.table" select="1"></xsl:param>

  <xsl:param name="funcsynopsis.tabular.threshold" select="0"></xsl:param>

<!--
  <xsl:param name="htmlhelp.hhp" select="'tnhScript2.hhp'"></xsl:param>
  <xsl:param name="htmlhelp.chm" select="'tnhScript2.chm'"></xsl:param>
 -->
  <xsl:param name="refentry.generate.name" select="0"></xsl:param>
  <xsl:param name="refentry.generate.title" select="1"></xsl:param>
  <xsl:param name="htmlhelp.encoding" select="'ISO-8859-1'"></xsl:param>
  <xsl:param name="htmlhelp.show.advanced.search" select="1"></xsl:param>
  <xsl:param name="htmlhelp.use.hhk" select="1"></xsl:param>
  <xsl:param name="htmlhelp.hhp.tail">
[FILES]
style.css
</xsl:param>

<xsl:include href="docbookosm.xsl" />

</xsl:stylesheet>