<xsl:stylesheet
  xmlns:xsl="http://www.w3.org/1999/XSL/Transform"
  version='1.0'>

  <xsl:import href="http://docbook.sourceforge.net/release/xsl/current/xhtml/docbook.xsl"/>
  <xsl:output method="xml" encoding="UTF-8" indent="no"/>
  <xsl:param name="html.stylesheet" select="'docbookosm.css'"></xsl:param>
  <xsl:param name="chunker.output.encoding" select="'UTF-8'"></xsl:param>
  <xsl:param name="chunk.first.sections" select="1"></xsl:param>
  <xsl:param name="label.from.part" select="1"></xsl:param>
  <xsl:param name="part.autolabel" select="0"></xsl:param>
  <xsl:param name="chapter.autolabel" select="1"></xsl:param>
  <xsl:param name="section.autolabel" select="0"></xsl:param>
  <xsl:param name="preface.autolabel" select="0"></xsl:param>
  <xsl:param name="appendix.autolabel" select="0"></xsl:param>
  <!-- xsl:param name="generate.id.attributes" select="0"></xsl:param -->

  <xsl:param name="generate.toc">
appendix  title
article/appendix  nop
article   toc,title
book      toc,title,figure,table,example,equation
chapter   title
part      toc,title
section   title
preface   nop
reference title
set       toc,title
refentry  title
  </xsl:param>
  <xsl:param name="refentry.generate.name" select="0"></xsl:param>
  <xsl:param name="refentry.generate.title" select="1"></xsl:param>
  <xsl:param name="refentry.pagebreak" select="0"></xsl:param>
  <xsl:param name="refentry.separator" select="0"></xsl:param>

  <xsl:param name="variablelist.as.table" select="1"></xsl:param>
  <xsl:param name="segmentedlist.as.table" select="1"></xsl:param>
  <xsl:param name="table.borders.with.css" select="1"></xsl:param>

  <xsl:param name="funcsynopsis.tabular.threshold" select="0"></xsl:param>

<xsl:include href="docbookosm.xsl" />

</xsl:stylesheet>